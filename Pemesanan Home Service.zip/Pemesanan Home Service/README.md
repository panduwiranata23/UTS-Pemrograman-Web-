#Aplikasi E-Commerce Penjualan Handphone (PHP, MySQL, JQuery Mobile)
Login pengguna:

Administrator:

    Username: admin
    Password: admin

Semoga bermanfaat.