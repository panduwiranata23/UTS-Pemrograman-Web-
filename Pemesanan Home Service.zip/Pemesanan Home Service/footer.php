
        <div class="left_footer">
        
        </div>
        
        <div class="center_footer">
        Pemesanan Home Service. All Rights Reserved 2020<br />
        </div>
        
        <div class="right_footer">
        <a href="index.php">home</a>
        <a href="profil-kami.html">profil</a>
        <a href="hubungi-kami.html">hubungi kami</a>
        <a href="login/index.php">login</a>
        </div>   
   