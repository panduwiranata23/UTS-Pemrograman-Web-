<li><a href="index.php" class="nav">  Beranda </a></li>
<li class="divider"></li>
<li><a href="profil-kami.html" class="nav">Profil</a></li>
<li class="divider"></li>
<li><a href="cara-pembelian.html" class="nav">Cara Pemesanan</a></li>
<li class="divider"></li>
<li><a href="semua-produk.html" class="nav">Pekerja</a></li>
<li class="divider"></li>
<li><a href="hubungi-kami.html" class="nav">Hubungi Kami</a></li>
<li class="divider"></li>