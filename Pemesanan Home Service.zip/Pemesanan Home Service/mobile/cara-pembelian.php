<p align="justify"><b>Cara Pembelian</b><br />
<li>Jika sudah selesai, maka akan tampil form untuk pengisian data kustomer/pembeli.</li>
<li>Setelah data pembeli selesai diisikan, klik tombol Proses, maka akan tampil data pembeli beserta produk yang dipesannya (jika diperlukan catat nomor order-nya). Dan juga ada total pembayaran serta nomor rekening pembayaran.</li>
<li>Apabila telah melakukan pembayaran, maka produk/barang akan segera kami kirimkan.</li>
<li>Anda dapat menghubungi contact person kami yaitu Okky Hendayana (085223123456).</li>
</p>